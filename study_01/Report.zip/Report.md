# Report study 01
Registered report: A coding-indpendent function of gene and psuedogene mRNAs regulates tumour biology

## Import libraries


```python
import pandas as pd
from scipy.stats import shapiro, levene
from statsmodels.formula.api import ols
from statsmodels.api import qqplot
from statsmodels.stats.anova import anova_lm
from statsmodels.stats.multitest import multipletests
from statsmodels.multivariate.manova import MANOVA
from sklearn.preprocessing import StandardScaler
```

## Protocol 1
Quantative PCR after miR transfection

### [Import data](https://osf.io/efvrs)



```python
data = pd.read_csv("data/Study_1_protocol_1_qPCR_Data.csv")
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sample</th>
      <th>Target</th>
      <th>Bio_rep</th>
      <th>Tech_rep</th>
      <th>Cq_36B4</th>
      <th>Cq_Actin</th>
      <th>Cq_PTEN</th>
      <th>Cq_PTENP1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>siLuc</td>
      <td>1</td>
      <td>1</td>
      <td>19.173930</td>
      <td>17.447433</td>
      <td>24.301085</td>
      <td>29.292576</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>siLuc</td>
      <td>1</td>
      <td>2</td>
      <td>18.830300</td>
      <td>17.122871</td>
      <td>24.048058</td>
      <td>28.750217</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>siLuc</td>
      <td>1</td>
      <td>3</td>
      <td>19.131717</td>
      <td>17.313650</td>
      <td>24.318525</td>
      <td>29.003423</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>miR19b</td>
      <td>1</td>
      <td>1</td>
      <td>18.851771</td>
      <td>17.486182</td>
      <td>24.279004</td>
      <td>29.280183</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>miR19b</td>
      <td>1</td>
      <td>2</td>
      <td>18.920350</td>
      <td>17.644964</td>
      <td>24.273985</td>
      <td>28.934185</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>23</td>
      <td>miR20a</td>
      <td>6</td>
      <td>2</td>
      <td>18.445929</td>
      <td>17.180244</td>
      <td>23.853842</td>
      <td>29.808641</td>
    </tr>
    <tr>
      <th>68</th>
      <td>23</td>
      <td>miR20a</td>
      <td>6</td>
      <td>3</td>
      <td>18.482267</td>
      <td>17.164726</td>
      <td>24.043568</td>
      <td>30.186486</td>
    </tr>
    <tr>
      <th>69</th>
      <td>24</td>
      <td>Untransfected</td>
      <td>6</td>
      <td>1</td>
      <td>19.643174</td>
      <td>17.580334</td>
      <td>24.635855</td>
      <td>31.108039</td>
    </tr>
    <tr>
      <th>70</th>
      <td>24</td>
      <td>Untransfected</td>
      <td>6</td>
      <td>2</td>
      <td>19.511646</td>
      <td>17.540498</td>
      <td>24.435515</td>
      <td>31.493541</td>
    </tr>
    <tr>
      <th>71</th>
      <td>24</td>
      <td>Untransfected</td>
      <td>6</td>
      <td>3</td>
      <td>19.545914</td>
      <td>17.505559</td>
      <td>24.336012</td>
      <td>31.613151</td>
    </tr>
  </tbody>
</table>
<p>72 rows × 8 columns</p>
</div>



### Analysis


```python
def shapiro_wilk_and_levene(data, column_names):
    levene_rows = []
    normalisers = {}
    for column_name in column_names:
        print(f"Shapiro-Wilk for {column_name}: {shapiro(data[column_name])}")
        qqplot(data[column_name])
        levene_rows.append(data[column_name])
        normalisers[column_name] = StandardScaler().fit(
            [[datapoint] for datapoint in data[column_name]]
        )
        data[f"{column_name}_standard"] = [
            datapoint[0]
            for datapoint in normalisers[column_name].transform(
                [[datapoint] for datapoint in data[column_name]]
            )
        ]
    print(f"Levene: {levene(*levene_rows[:-1])}")
    return data, normalisers

def protocol1_analysis(data, column):
    print(f"MANOVA analysis for {column}")
    print(
        MANOVA.from_formula(
            f"C(Target) ~ {column}",
            data=data[data["Target"].isin(["siLuc", "miR19b", "miR20a"])],
        ).mv_test()
    )
    formula = f"{column} ~ C(Target)"
    lm = ols(formula, data[data["Target"].isin(["siLuc", "miR19b"])]).fit()
    print(f"ANOVA analysis for {column} with targets siLuc and miR19b")
    print(lm.summary())
    print(anova_lm(lm))
    formula = f"{column} ~ C(Target)"
    lm = ols(formula, data[data["Target"].isin(["siLuc", "miR20a"])]).fit()
    print(f"ANOVA analysis for {column} with targets siLuc and miR20a")
    print(lm.summary())
    print(anova_lm(lm))
```

**Shapiro-Wilk test and Levene test**


```python
column_names = ["Cq_36B4", "Cq_Actin", "Cq_PTEN", "Cq_PTENP1"]
data, normalisers = shapiro_wilk_and_levene(data, column_names)
```

    Shapiro-Wilk for Cq_36B4: ShapiroResult(statistic=0.987586498260498, pvalue=0.7041038274765015)
    Shapiro-Wilk for Cq_Actin: ShapiroResult(statistic=0.8178163170814514, pvalue=5.3428305335501136e-08)
    Shapiro-Wilk for Cq_PTEN: ShapiroResult(statistic=0.8790109157562256, pvalue=4.864089532929938e-06)
    Shapiro-Wilk for Cq_PTENP1: ShapiroResult(statistic=nan, pvalue=1.0)
    Levene: LeveneResult(statistic=2.0844863310953077, pvalue=0.12690084915833996)



    
![png](output_9_1.png)
    



    
![png](output_9_2.png)
    



    
![png](output_9_3.png)
    



    
![png](output_9_4.png)
    


**MANOVA and ANOVA**


```python
for column_name in column_names:
    protocol1_analysis(data, column_name + "_standard")
```

    MANOVA analysis for Cq_36B4_standard
                     Multivariate linear model
    ============================================================
                                                                
    ------------------------------------------------------------
           Intercept        Value  Num DF  Den DF F Value Pr > F
    ------------------------------------------------------------
              Wilks' lambda 0.0000 3.0000 50.0000     inf 0.0000
             Pillai's trace 1.0000 3.0000 50.0000     inf 0.0000
     Hotelling-Lawley trace    inf 3.0000 50.0000     inf 0.0000
        Roy's greatest root    inf 3.0000 50.0000     inf 0.0000
    ------------------------------------------------------------
                                                                
    ------------------------------------------------------------
        Cq_36B4_standard    Value  Num DF  Den DF F Value Pr > F
    ------------------------------------------------------------
              Wilks' lambda 0.9084 2.0000 51.0000  2.5719 0.0863
             Pillai's trace 0.0918 2.0000 51.0000  2.5781 0.0858
     Hotelling-Lawley trace 0.1006 2.0000 51.0000  2.5663 0.0867
        Roy's greatest root 0.0984 2.0000 51.0000  2.5093 0.0913
    ============================================================
    
    ANOVA analysis for Cq_36B4_standard with targets siLuc and miR19b
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_36B4_standard   R-squared:                       0.159
    Model:                            OLS   Adj. R-squared:                  0.134
    Method:                 Least Squares   F-statistic:                     6.420
    Date:                Mon, 08 May 2023   Prob (F-statistic):             0.0161
    Time:                        22:45:05   Log-Likelihood:                -40.416
    No. Observations:                  36   AIC:                             84.83
    Df Residuals:                      34   BIC:                             88.00
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept              0.1109      0.180      0.615      0.543      -0.256       0.477
    C(Target)[T.siLuc]    -0.6463      0.255     -2.534      0.016      -1.165      -0.128
    ==============================================================================
    Omnibus:                        6.031   Durbin-Watson:                   0.969
    Prob(Omnibus):                  0.049   Jarque-Bera (JB):                2.015
    Skew:                          -0.041   Prob(JB):                        0.365
    Kurtosis:                       1.844   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   3.758775  3.758775  6.420495  0.016057
    Residual   34.0  19.904751  0.585434       NaN       NaN
    ANOVA analysis for Cq_36B4_standard with targets siLuc and miR20a
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_36B4_standard   R-squared:                       0.061
    Model:                            OLS   Adj. R-squared:                  0.033
    Method:                 Least Squares   F-statistic:                     2.208
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.147
    Time:                        22:45:05   Log-Likelihood:                -52.087
    No. Observations:                  36   AIC:                             108.2
    Df Residuals:                      34   BIC:                             111.3
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept             -0.0113      0.249     -0.045      0.964      -0.518       0.496
    C(Target)[T.siLuc]    -0.5241      0.353     -1.486      0.147      -1.241       0.193
    ==============================================================================
    Omnibus:                        5.728   Durbin-Watson:                   0.897
    Prob(Omnibus):                  0.057   Jarque-Bera (JB):                1.966
    Skew:                          -0.035   Prob(JB):                        0.374
    Kurtosis:                       1.857   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F   PR(>F)
    C(Target)   1.0   2.471849  2.471849  2.207784  0.14653
    Residual   34.0  38.066628  1.119607       NaN      NaN
    MANOVA analysis for Cq_Actin_standard
                     Multivariate linear model
    ============================================================
                                                                
    ------------------------------------------------------------
           Intercept        Value  Num DF  Den DF F Value Pr > F
    ------------------------------------------------------------
              Wilks' lambda 0.0000 3.0000 50.0000     inf 0.0000
             Pillai's trace 1.0000 3.0000 50.0000     inf 0.0000
     Hotelling-Lawley trace    inf 3.0000 50.0000     inf 0.0000
        Roy's greatest root    inf 3.0000 50.0000     inf 0.0000
    ------------------------------------------------------------
                                                                
    ------------------------------------------------------------
       Cq_Actin_standard    Value  Num DF  Den DF F Value Pr > F
    ------------------------------------------------------------
              Wilks' lambda 0.9318 2.0000 51.0000  1.8659 0.1652
             Pillai's trace 0.0683 2.0000 51.0000  1.8685 0.1648
     Hotelling-Lawley trace 0.0731 2.0000 51.0000  1.8636 0.1655
        Roy's greatest root 0.0718 2.0000 51.0000  1.8303 0.1707
    ============================================================
    
    ANOVA analysis for Cq_Actin_standard with targets siLuc and miR19b
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:      Cq_Actin_standard   R-squared:                       0.040
    Model:                            OLS   Adj. R-squared:                  0.012
    Method:                 Least Squares   F-statistic:                     1.421
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.242
    Time:                        22:45:05   Log-Likelihood:                -32.837
    No. Observations:                  36   AIC:                             69.67
    Df Residuals:                      34   BIC:                             72.84
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept             -0.1343      0.146     -0.919      0.364      -0.431       0.163
    C(Target)[T.siLuc]    -0.2463      0.207     -1.192      0.242      -0.666       0.174
    ==============================================================================
    Omnibus:                        3.432   Durbin-Watson:                   1.392
    Prob(Omnibus):                  0.180   Jarque-Bera (JB):                2.130
    Skew:                           0.498   Prob(JB):                        0.345
    Kurtosis:                       3.656   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   0.545912  0.545912  1.420692  0.241543
    Residual   34.0  13.064762  0.384258       NaN       NaN
    ANOVA analysis for Cq_Actin_standard with targets siLuc and miR20a
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:      Cq_Actin_standard   R-squared:                       0.078
    Model:                            OLS   Adj. R-squared:                  0.051
    Method:                 Least Squares   F-statistic:                     2.887
    Date:                Mon, 08 May 2023   Prob (F-statistic):             0.0984
    Time:                        22:45:05   Log-Likelihood:                -56.630
    No. Observations:                  36   AIC:                             117.3
    Df Residuals:                      34   BIC:                             120.4
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept              0.2993      0.283      1.058      0.298      -0.276       0.874
    C(Target)[T.siLuc]    -0.6799      0.400     -1.699      0.098      -1.493       0.133
    ==============================================================================
    Omnibus:                       24.529   Durbin-Watson:                   0.911
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):               39.988
    Skew:                           1.828   Prob(JB):                     2.07e-09
    Kurtosis:                       6.646   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F   PR(>F)
    C(Target)   1.0   4.160193  4.160193  2.886835  0.09844
    Residual   34.0  48.997106  1.441091       NaN      NaN
    MANOVA analysis for Cq_PTEN_standard
                                     Multivariate linear model
    ============================================================================================
                                                                                                
    --------------------------------------------------------------------------------------------
           Intercept                Value          Num DF  Den DF         F Value         Pr > F
    --------------------------------------------------------------------------------------------
              Wilks' lambda                -0.0000 3.0000 50.0000 -37529996894754152.0000 1.0000
             Pillai's trace                 1.0000 3.0000 50.0000 -37529996894754152.0000 1.0000
     Hotelling-Lawley trace -2251799813685249.0000 3.0000 50.0000 -37529996894754152.0000 1.0000
        Roy's greatest root -2251799813685249.0000 3.0000 50.0000 -37529996894754152.0000 1.0000
    --------------------------------------------------------------------------------------------
                                                                                                
    --------------------------------------------------------------------------------------------------
                Cq_PTEN_standard          Value        Num DF        Den DF       F Value       Pr > F
    --------------------------------------------------------------------------------------------------
                      Wilks' lambda       0.7398       3.0000       50.0000        5.8609       0.0016
                     Pillai's trace       0.2602       3.0000       50.0000        5.8609       0.0016
             Hotelling-Lawley trace       0.3517       3.0000       50.0000        5.8609       0.0016
                Roy's greatest root       0.3517       3.0000       50.0000        5.8609       0.0016
    ============================================================================================
    
    ANOVA analysis for Cq_PTEN_standard with targets siLuc and miR19b
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_PTEN_standard   R-squared:                       0.291
    Model:                            OLS   Adj. R-squared:                  0.270
    Method:                 Least Squares   F-statistic:                     13.98
    Date:                Mon, 08 May 2023   Prob (F-statistic):           0.000681
    Time:                        22:45:05   Log-Likelihood:                -28.750
    No. Observations:                  36   AIC:                             61.50
    Df Residuals:                      34   BIC:                             64.67
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept             -0.0271      0.130     -0.208      0.836      -0.292       0.238
    C(Target)[T.siLuc]    -0.6895      0.184     -3.738      0.001      -1.064      -0.315
    ==============================================================================
    Omnibus:                        0.991   Durbin-Watson:                   1.233
    Prob(Omnibus):                  0.609   Jarque-Bera (JB):                0.856
    Skew:                          -0.091   Prob(JB):                        0.652
    Kurtosis:                       2.267   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq          F    PR(>F)
    C(Target)   1.0   4.279172  4.279172  13.975123  0.000681
    Residual   34.0  10.410773  0.306199        NaN       NaN
    ANOVA analysis for Cq_PTEN_standard with targets siLuc and miR20a
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_PTEN_standard   R-squared:                       0.279
    Model:                            OLS   Adj. R-squared:                  0.257
    Method:                 Least Squares   F-statistic:                     13.13
    Date:                Mon, 08 May 2023   Prob (F-statistic):           0.000940
    Time:                        22:45:05   Log-Likelihood:                -53.366
    No. Observations:                  36   AIC:                             110.7
    Df Residuals:                      34   BIC:                             113.9
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept              0.6074      0.258      2.350      0.025       0.082       1.133
    C(Target)[T.siLuc]    -1.3241      0.365     -3.623      0.001      -2.067      -0.581
    ==============================================================================
    Omnibus:                       21.442   Durbin-Watson:                   0.712
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):               31.808
    Skew:                           1.631   Prob(JB):                     1.24e-07
    Kurtosis:                       6.251   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq    mean_sq          F   PR(>F)
    C(Target)   1.0  15.778697  15.778697  13.126028  0.00094
    Residual   34.0  40.871138   1.202092        NaN      NaN
    MANOVA analysis for Cq_PTENP1_standard
                                    Multivariate linear model
    ==========================================================================================
                                                                                              
    ------------------------------------------------------------------------------------------
           Intercept                Value         Num DF  Den DF        F Value         Pr > F
    ------------------------------------------------------------------------------------------
              Wilks' lambda                0.0000 3.0000 50.0000 75059993789508240.0000 0.0000
             Pillai's trace                1.0000 3.0000 50.0000 75059993789508256.0000 0.0000
     Hotelling-Lawley trace 4503599627370495.0000 3.0000 50.0000 75059993789508256.0000 0.0000
        Roy's greatest root 4503599627370495.0000 3.0000 50.0000 75059993789508256.0000 0.0000
    ------------------------------------------------------------------------------------------
                                                                                              
    ------------------------------------------------------------------------------------------------
             Cq_PTENP1_standard         Value        Num DF        Den DF       F Value       Pr > F
    ------------------------------------------------------------------------------------------------
                    Wilks' lambda       0.9349       2.0000       51.0000        1.7744       0.1799
                   Pillai's trace       0.0654       2.0000       51.0000        1.7841       0.1783
           Hotelling-Lawley trace       0.0692       2.0000       51.0000        1.7654       0.1814
              Roy's greatest root       0.0637       2.0000       51.0000        1.6235       0.2072
    ==========================================================================================
    
    ANOVA analysis for Cq_PTENP1_standard with targets siLuc and miR19b
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:     Cq_PTENP1_standard   R-squared:                       0.025
    Model:                            OLS   Adj. R-squared:                 -0.004
    Method:                 Least Squares   F-statistic:                    0.8582
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.361
    Time:                        22:45:05   Log-Likelihood:                -46.107
    No. Observations:                  36   AIC:                             96.21
    Df Residuals:                      34   BIC:                             99.38
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept              0.1466      0.211      0.694      0.492      -0.283       0.576
    C(Target)[T.siLuc]    -0.2767      0.299     -0.926      0.361      -0.884       0.330
    ==============================================================================
    Omnibus:                        3.208   Durbin-Watson:                   0.754
    Prob(Omnibus):                  0.201   Jarque-Bera (JB):                2.743
    Skew:                           0.670   Prob(JB):                        0.254
    Kurtosis:                       2.820   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   0.689269  0.689269  0.858229  0.360764
    Residual   34.0  27.306391  0.803129       NaN       NaN
    ANOVA analysis for Cq_PTENP1_standard with targets siLuc and miR20a
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:     Cq_PTENP1_standard   R-squared:                       0.100
    Model:                            OLS   Adj. R-squared:                  0.074
    Method:                 Least Squares   F-statistic:                     3.777
    Date:                Mon, 08 May 2023   Prob (F-statistic):             0.0603
    Time:                        22:45:05   Log-Likelihood:                -40.289
    No. Observations:                  36   AIC:                             84.58
    Df Residuals:                      34   BIC:                             87.74
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept              0.3638      0.180      2.024      0.051      -0.001       0.729
    C(Target)[T.siLuc]    -0.4939      0.254     -1.943      0.060      -1.010       0.023
    ==============================================================================
    Omnibus:                        6.321   Durbin-Watson:                   1.016
    Prob(Omnibus):                  0.042   Jarque-Bera (JB):                4.975
    Skew:                           0.867   Prob(JB):                       0.0831
    Kurtosis:                       3.554   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   2.195438  2.195438  3.776696  0.060287
    Residual   34.0  19.764602  0.581312       NaN       NaN


    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/multivariate/multivariate_ols.py:168: RuntimeWarning: divide by zero encountered in scalar divide
      eigv1 = np.array([i / (1 - i) for i in eigv2])
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/multivariate/multivariate_ols.py:199: RuntimeWarning: divide by zero encountered in scalar divide
      F = (1 - lmd) / lmd * df2 / df1
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/multivariate/multivariate_ols.py:209: RuntimeWarning: divide by zero encountered in scalar divide
      F = df2 / df1 * V / (s - V)
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/multivariate/multivariate_ols.py:168: RuntimeWarning: divide by zero encountered in scalar divide
      eigv1 = np.array([i / (1 - i) for i in eigv2])
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/multivariate/multivariate_ols.py:199: RuntimeWarning: divide by zero encountered in scalar divide
      F = (1 - lmd) / lmd * df2 / df1
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/multivariate/multivariate_ols.py:209: RuntimeWarning: divide by zero encountered in scalar divide
      F = df2 / df1 * V / (s - V)


## Protocol 2
### [Import AUC data](https://osf.io/d65gu)
### [Import absorption data](https://osf.io/vwu6d)


```python
auc_data = pd.read_csv("data/Study_1_Protocol_2_AUC.csv")
auc_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>treatment</th>
      <th>AUC</th>
      <th>Repeat</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Untransfected</td>
      <td>28.216667</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Untransfected</td>
      <td>42.129730</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Untransfected</td>
      <td>43.459239</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Untransfected</td>
      <td>50.112676</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Untransfected</td>
      <td>40.281250</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>SiLUC</td>
      <td>27.146552</td>
      <td>1</td>
    </tr>
    <tr>
      <th>6</th>
      <td>SiLUC</td>
      <td>14.931452</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>SiLUC</td>
      <td>14.337500</td>
      <td>3</td>
    </tr>
    <tr>
      <th>8</th>
      <td>SiLUC</td>
      <td>25.653061</td>
      <td>4</td>
    </tr>
    <tr>
      <th>9</th>
      <td>SiLUC</td>
      <td>21.173469</td>
      <td>5</td>
    </tr>
    <tr>
      <th>10</th>
      <td>siPTen</td>
      <td>23.591216</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11</th>
      <td>siPTen</td>
      <td>24.761905</td>
      <td>2</td>
    </tr>
    <tr>
      <th>12</th>
      <td>siPTen</td>
      <td>19.608247</td>
      <td>3</td>
    </tr>
    <tr>
      <th>13</th>
      <td>siPTen</td>
      <td>22.223529</td>
      <td>4</td>
    </tr>
    <tr>
      <th>14</th>
      <td>siPTen</td>
      <td>18.655405</td>
      <td>5</td>
    </tr>
    <tr>
      <th>15</th>
      <td>siPTENP1</td>
      <td>31.771028</td>
      <td>1</td>
    </tr>
    <tr>
      <th>16</th>
      <td>siPTENP1</td>
      <td>43.436170</td>
      <td>2</td>
    </tr>
    <tr>
      <th>17</th>
      <td>siPTENP1</td>
      <td>65.600000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>18</th>
      <td>siPTENP1</td>
      <td>32.158654</td>
      <td>4</td>
    </tr>
    <tr>
      <th>19</th>
      <td>siPTENP1</td>
      <td>23.905556</td>
      <td>5</td>
    </tr>
    <tr>
      <th>20</th>
      <td>PTENPTENP1sp</td>
      <td>32.778351</td>
      <td>1</td>
    </tr>
    <tr>
      <th>21</th>
      <td>PTENPTENP1sp</td>
      <td>43.022059</td>
      <td>2</td>
    </tr>
    <tr>
      <th>22</th>
      <td>PTENPTENP1sp</td>
      <td>48.953846</td>
      <td>3</td>
    </tr>
    <tr>
      <th>23</th>
      <td>PTENPTENP1sp</td>
      <td>56.550633</td>
      <td>4</td>
    </tr>
    <tr>
      <th>24</th>
      <td>PTENPTENP1sp</td>
      <td>19.220183</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
absorption_array = [
    [
        "treatment",
        "Day0",
        "Day1",
        "Day2",
        "Day3",
        "Day4",
        "Day5",
    ],
    ["Untransfected", 1, 1.889482, 4.657466, 8.20607, 14.92044, 21.3329],
    ["SiLUC", 1, 1.806047, 2.918309, 4.21260, 6.117074, 10.18875],
    ["siPTen", 1, 1.380741, 2.661187, 4.12525, 7.025456, 12.15085],
    ["siPTENP1", 1, 1.965311, 4.119877, 7.29807, 13.42901, 24.12403],
    ["PTENPTENP1sp", 1, 1.9136, 4.167691, 7.66188, 13.38172, 24.96025],
]
absorption_data = pd.DataFrame(absorption_array[1:], columns=absorption_array[0])
absorption_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>treatment</th>
      <th>Day0</th>
      <th>Day1</th>
      <th>Day2</th>
      <th>Day3</th>
      <th>Day4</th>
      <th>Day5</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Untransfected</td>
      <td>1</td>
      <td>1.889482</td>
      <td>4.657466</td>
      <td>8.20607</td>
      <td>14.920440</td>
      <td>21.33290</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SiLUC</td>
      <td>1</td>
      <td>1.806047</td>
      <td>2.918309</td>
      <td>4.21260</td>
      <td>6.117074</td>
      <td>10.18875</td>
    </tr>
    <tr>
      <th>2</th>
      <td>siPTen</td>
      <td>1</td>
      <td>1.380741</td>
      <td>2.661187</td>
      <td>4.12525</td>
      <td>7.025456</td>
      <td>12.15085</td>
    </tr>
    <tr>
      <th>3</th>
      <td>siPTENP1</td>
      <td>1</td>
      <td>1.965311</td>
      <td>4.119877</td>
      <td>7.29807</td>
      <td>13.429010</td>
      <td>24.12403</td>
    </tr>
    <tr>
      <th>4</th>
      <td>PTENPTENP1sp</td>
      <td>1</td>
      <td>1.913600</td>
      <td>4.167691</td>
      <td>7.66188</td>
      <td>13.381720</td>
      <td>24.96025</td>
    </tr>
  </tbody>
</table>
</div>



### Analysis


```python
def protocol2_analysis(data, target_column):
    comparisons = [
        ("SiLUC", "siPTen"),
        ("SiLUC", "siPTENP1"),
        ("SiLUC", "PTENPTENP1sp"),
        ("PTENPTENP1sp", "siPTen"),
        ("PTENPTENP1sp", "siPTENP1"),
    ]
    formula = f"{target_column} ~ C(treatment)"
    for first, second in comparisons:
        print(f"Comparison of {first} with {second}")
        specified_data = data[data["treatment"].isin((first, second))]
        lm = ols(formula, specified_data).fit()
        print(lm.summary())
        anova_table = anova_lm(lm)
        print(anova_table)
        # Bonferroni
        print("Bonferroni")
        print(
            multipletests(
                anova_table["PR(>F)"].dropna(), alpha=0.025, method="bonferroni"
            )
        )
```

**Shapiro-Wilk test and Levene test**


```python
_, _ = shapiro_wilk_and_levene(auc_data, ["AUC"])
```

    Shapiro-Wilk for AUC: ShapiroResult(statistic=0.9325029850006104, pvalue=0.09929066896438599)



    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[9], line 1
    ----> 1 _, _ = shapiro_wilk_and_levene(auc_data, ["AUC"])


    Cell In[3], line 17, in shapiro_wilk_and_levene(data, column_names)
          8     normalisers[column_name] = StandardScaler().fit(
          9         [[datapoint] for datapoint in data[column_name]]
         10     )
         11     data[f"{column_name}_standard"] = [
         12         datapoint[0]
         13         for datapoint in normalisers[column_name].transform(
         14             [[datapoint] for datapoint in data[column_name]]
         15         )
         16     ]
    ---> 17 print(f"Levene: {levene(*levene_rows[:-1])}")
         18 return data, normalisers


    File ~/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/scipy/stats/_morestats.py:2665, in levene(center, proportiontocut, *samples)
       2663 k = len(samples)
       2664 if k < 2:
    -> 2665     raise ValueError("Must enter at least two input sample vectors.")
       2666 # check for 1d input
       2667 for j in range(k):


    ValueError: Must enter at least two input sample vectors.



    
![png](output_18_2.png)
    



```python
_, _ = shapiro_wilk_and_levene(absorption_data, ["Day5"])
```

    Shapiro-Wilk for Day5: ShapiroResult(statistic=0.8464969396591187, pvalue=0.18369729816913605)



    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[10], line 1
    ----> 1 _, _ = shapiro_wilk_and_levene(absorption_data, ["Day5"])


    Cell In[3], line 17, in shapiro_wilk_and_levene(data, column_names)
          8     normalisers[column_name] = StandardScaler().fit(
          9         [[datapoint] for datapoint in data[column_name]]
         10     )
         11     data[f"{column_name}_standard"] = [
         12         datapoint[0]
         13         for datapoint in normalisers[column_name].transform(
         14             [[datapoint] for datapoint in data[column_name]]
         15         )
         16     ]
    ---> 17 print(f"Levene: {levene(*levene_rows[:-1])}")
         18 return data, normalisers


    File ~/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/scipy/stats/_morestats.py:2665, in levene(center, proportiontocut, *samples)
       2663 k = len(samples)
       2664 if k < 2:
    -> 2665     raise ValueError("Must enter at least two input sample vectors.")
       2666 # check for 1d input
       2667 for j in range(k):


    ValueError: Must enter at least two input sample vectors.



    
![png](output_19_2.png)
    



```python
protocol2_analysis(auc_data, "AUC")
```

    Comparison of SiLUC with siPTen
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                    AUC   R-squared:                       0.018
    Model:                            OLS   Adj. R-squared:                 -0.104
    Method:                 Least Squares   F-statistic:                    0.1502
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.708
    Time:                        22:45:15   Log-Likelihood:                -28.264
    No. Observations:                  10   AIC:                             60.53
    Df Residuals:                       8   BIC:                             61.13
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==========================================================================================
                                 coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------------------
    Intercept                 20.6484      2.043     10.108      0.000      15.938      25.359
    C(treatment)[T.siPTen]     1.1197      2.889      0.388      0.708      -5.542       7.781
    ==============================================================================
    Omnibus:                        0.568   Durbin-Watson:                   2.078
    Prob(Omnibus):                  0.753   Jarque-Bera (JB):                0.519
    Skew:                          -0.067   Prob(JB):                        0.772
    Kurtosis:                       1.892   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                   df      sum_sq    mean_sq         F    PR(>F)
    C(treatment)  1.0    3.134062   3.134062  0.150218  0.708435
    Residual      8.0  166.907132  20.863391       NaN       NaN
    Bonferroni
    (array([False]), array([0.70843506]), 0.025000000000000022, 0.025)
    Comparison of SiLUC with siPTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                    AUC   R-squared:                       0.423
    Model:                            OLS   Adj. R-squared:                  0.351
    Method:                 Least Squares   F-statistic:                     5.876
    Date:                Mon, 08 May 2023   Prob (F-statistic):             0.0416
    Time:                        22:45:15   Log-Likelihood:                -38.100
    No. Observations:                  10   AIC:                             80.20
    Df Residuals:                       8   BIC:                             80.80
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ============================================================================================
                                   coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------------
    Intercept                   20.6484      5.462      3.780      0.005       8.052      33.245
    C(treatment)[T.siPTENP1]    18.7259      7.725      2.424      0.042       0.912      36.540
    ==============================================================================
    Omnibus:                        5.769   Durbin-Watson:                   1.824
    Prob(Omnibus):                  0.056   Jarque-Bera (JB):                2.068
    Skew:                           1.039   Prob(JB):                        0.355
    Kurtosis:                       3.803   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                   df       sum_sq     mean_sq         F    PR(>F)
    C(treatment)  1.0   876.645962  876.645962  5.876122  0.041585
    Residual      8.0  1193.502744  149.187843       NaN       NaN
    Bonferroni
    (array([False]), array([0.0415851]), 0.025000000000000022, 0.025)
    Comparison of SiLUC with PTENPTENP1sp
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                    AUC   R-squared:                       0.489
    Model:                            OLS   Adj. R-squared:                  0.426
    Method:                 Least Squares   F-statistic:                     7.669
    Date:                Mon, 08 May 2023   Prob (F-statistic):             0.0243
    Time:                        22:45:15   Log-Likelihood:                -37.151
    No. Observations:                  10   AIC:                             78.30
    Df Residuals:                       8   BIC:                             78.91
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =========================================================================================
                                coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------------
    Intercept                40.1050      4.968      8.073      0.000      28.649      51.561
    C(treatment)[T.SiLUC]   -19.4566      7.026     -2.769      0.024     -35.658      -3.256
    ==============================================================================
    Omnibus:                        1.119   Durbin-Watson:                   1.976
    Prob(Omnibus):                  0.572   Jarque-Bera (JB):                0.341
    Skew:                          -0.446   Prob(JB):                        0.843
    Kurtosis:                       2.848   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                   df      sum_sq     mean_sq         F   PR(>F)
    C(treatment)  1.0  946.398947  946.398947  7.669478  0.02432
    Residual      8.0  987.184771  123.398096       NaN      NaN
    Bonferroni
    (array([ True]), array([0.02431987]), 0.025000000000000022, 0.025)
    Comparison of PTENPTENP1sp with siPTen
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                    AUC   R-squared:                       0.490
    Model:                            OLS   Adj. R-squared:                  0.427
    Method:                 Least Squares   F-statistic:                     7.695
    Date:                Mon, 08 May 2023   Prob (F-statistic):             0.0242
    Time:                        22:45:15   Log-Likelihood:                -36.542
    No. Observations:                  10   AIC:                             77.08
    Df Residuals:                       8   BIC:                             77.69
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==========================================================================================
                                 coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------------------
    Intercept                 40.1050      4.674      8.580      0.000      29.326      50.884
    C(treatment)[T.siPTen]   -18.3370      6.610     -2.774      0.024     -33.581      -3.093
    ==============================================================================
    Omnibus:                        2.880   Durbin-Watson:                   1.896
    Prob(Omnibus):                  0.237   Jarque-Bera (JB):                0.607
    Skew:                          -0.532   Prob(JB):                        0.738
    Kurtosis:                       3.570   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                   df      sum_sq     mean_sq         F   PR(>F)
    C(treatment)  1.0  840.609681  840.609681  7.694602  0.02415
    Residual      8.0  873.973372  109.246672       NaN      NaN
    Bonferroni
    (array([ True]), array([0.02415031]), 0.025000000000000022, 0.025)
    Comparison of PTENPTENP1sp with siPTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                    AUC   R-squared:                       0.001
    Model:                            OLS   Adj. R-squared:                 -0.124
    Method:                 Least Squares   F-statistic:                  0.005619
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.942
    Time:                        22:45:15   Log-Likelihood:                -40.426
    No. Observations:                  10   AIC:                             84.85
    Df Residuals:                       8   BIC:                             85.46
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ============================================================================================
                                   coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------------
    Intercept                   40.1050      6.893      5.818      0.000      24.210      56.000
    C(treatment)[T.siPTENP1]    -0.7307      9.748     -0.075      0.942     -23.210      21.749
    ==============================================================================
    Omnibus:                        0.410   Durbin-Watson:                   1.827
    Prob(Omnibus):                  0.814   Jarque-Bera (JB):                0.448
    Skew:                           0.353   Prob(JB):                        0.799
    Kurtosis:                       2.240   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                   df       sum_sq     mean_sq         F    PR(>F)
    C(treatment)  1.0     1.334926    1.334926  0.005619  0.942087
    Residual      8.0  1900.568985  237.571123       NaN       NaN
    Bonferroni
    (array([False]), array([0.94208679]), 0.025000000000000022, 0.025)


    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/scipy/stats/_stats_py.py:1736: UserWarning: kurtosistest only valid for n>=20 ... continuing anyway, n=10
      warnings.warn("kurtosistest only valid for n>=20 ... continuing "
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/scipy/stats/_stats_py.py:1736: UserWarning: kurtosistest only valid for n>=20 ... continuing anyway, n=10
      warnings.warn("kurtosistest only valid for n>=20 ... continuing "
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/scipy/stats/_stats_py.py:1736: UserWarning: kurtosistest only valid for n>=20 ... continuing anyway, n=10
      warnings.warn("kurtosistest only valid for n>=20 ... continuing "
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/scipy/stats/_stats_py.py:1736: UserWarning: kurtosistest only valid for n>=20 ... continuing anyway, n=10
      warnings.warn("kurtosistest only valid for n>=20 ... continuing "
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/scipy/stats/_stats_py.py:1736: UserWarning: kurtosistest only valid for n>=20 ... continuing anyway, n=10
      warnings.warn("kurtosistest only valid for n>=20 ... continuing "



```python
protocol2_analysis(absorption_data, "Day5")
```

    Comparison of SiLUC with siPTen
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                   Day5   R-squared:                       1.000
    Model:                            OLS   Adj. R-squared:                    nan
    Method:                 Least Squares   F-statistic:                       nan
    Date:                Mon, 08 May 2023   Prob (F-statistic):                nan
    Time:                        22:45:17   Log-Likelihood:                 64.397
    No. Observations:                   2   AIC:                            -124.8
    Df Residuals:                       0   BIC:                            -127.4
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==========================================================================================
                                 coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------------------
    Intercept                 10.1888        inf          0        nan         nan         nan
    C(treatment)[T.siPTen]     1.9621        inf          0        nan         nan         nan
    ==============================================================================
    Omnibus:                          nan   Durbin-Watson:                   1.000
    Prob(Omnibus):                    nan   Jarque-Bera (JB):                0.333
    Skew:                           0.000   Prob(JB):                        0.846
    Kurtosis:                       1.000   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                   df        sum_sq   mean_sq    F  PR(>F)
    C(treatment)  1.0  1.924918e+00  1.924918  0.0     NaN
    Residual      0.0  1.262177e-29       inf  NaN     NaN
    Bonferroni


    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/stats/stattools.py:74: ValueWarning: omni_normtest is not valid with less than 8 observations; 2 samples were given.
      warn("omni_normtest is not valid with less than 8 observations; %i "
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/regression/linear_model.py:1765: RuntimeWarning: divide by zero encountered in divide
      return 1 - (np.divide(self.nobs - self.k_constant, self.df_resid)
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/regression/linear_model.py:1765: RuntimeWarning: invalid value encountered in scalar multiply
      return 1 - (np.divide(self.nobs - self.k_constant, self.df_resid)
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/regression/linear_model.py:1687: RuntimeWarning: divide by zero encountered in scalar divide
      return np.dot(wresid, wresid) / self.df_resid
    /home/jannik-gut/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/stats/anova.py:138: RuntimeWarning: divide by zero encountered in scalar divide
      (model.ssr / model.df_resid))



    ---------------------------------------------------------------------------

    ZeroDivisionError                         Traceback (most recent call last)

    Cell In[12], line 1
    ----> 1 protocol2_analysis(absorption_data, "Day5")


    Cell In[8], line 20, in protocol2_analysis(data, target_column)
         17 # Bonferroni
         18 print("Bonferroni")
         19 print(
    ---> 20     multipletests(
         21         anova_table["PR(>F)"].dropna(), alpha=0.025, method="bonferroni"
         22     )
         23 )


    File ~/miniconda3/envs/reproducibility_hackathon/lib/python3.11/site-packages/statsmodels/stats/multitest.py:147, in multipletests(pvals, alpha, method, is_sorted, returnsorted)
        144     pvals = np.take(pvals, sortind)
        146 ntests = len(pvals)
    --> 147 alphacSidak = 1 - np.power((1. - alphaf), 1./ntests)
        148 alphacBonf = alphaf / float(ntests)
        149 if method.lower() in ['b', 'bonf', 'bonferroni']:


    ZeroDivisionError: float division by zero


**only one datapoint per treatment in data &rightarrow; ZeroDivisionError**

## Protocol 3
### [Import data](https://osf.io/5dp68)


```python
data = pd.read_csv("data/Cq_P3_031617.csv")
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Target</th>
      <th>Replicate</th>
      <th>Cq_36B4</th>
      <th>Cq_Actin</th>
      <th>Cq_PTEN</th>
      <th>Cq_PTENP1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>untransfected</td>
      <td>1</td>
      <td>17.44</td>
      <td>16.08</td>
      <td>22.99</td>
      <td>30.44</td>
    </tr>
    <tr>
      <th>1</th>
      <td>untransfected</td>
      <td>1</td>
      <td>17.37</td>
      <td>16.01</td>
      <td>22.96</td>
      <td>30.41</td>
    </tr>
    <tr>
      <th>2</th>
      <td>untransfected</td>
      <td>1</td>
      <td>17.62</td>
      <td>15.84</td>
      <td>23.00</td>
      <td>30.22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>siLuc</td>
      <td>1</td>
      <td>17.72</td>
      <td>15.62</td>
      <td>23.29</td>
      <td>30.09</td>
    </tr>
    <tr>
      <th>4</th>
      <td>siLuc</td>
      <td>1</td>
      <td>17.52</td>
      <td>15.56</td>
      <td>23.55</td>
      <td>30.19</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>siPTENP1</td>
      <td>5</td>
      <td>19.68</td>
      <td>16.85</td>
      <td>25.61</td>
      <td>33.48</td>
    </tr>
    <tr>
      <th>71</th>
      <td>siPTENP1</td>
      <td>5</td>
      <td>19.66</td>
      <td>17.08</td>
      <td>25.69</td>
      <td>33.24</td>
    </tr>
    <tr>
      <th>72</th>
      <td>siPTEN/PTENP1</td>
      <td>5</td>
      <td>19.34</td>
      <td>16.86</td>
      <td>26.72</td>
      <td>32.77</td>
    </tr>
    <tr>
      <th>73</th>
      <td>siPTEN/PTENP1</td>
      <td>5</td>
      <td>19.40</td>
      <td>16.82</td>
      <td>26.78</td>
      <td>33.17</td>
    </tr>
    <tr>
      <th>74</th>
      <td>siPTEN/PTENP1</td>
      <td>5</td>
      <td>19.43</td>
      <td>17.00</td>
      <td>26.62</td>
      <td>32.62</td>
    </tr>
  </tbody>
</table>
<p>75 rows × 6 columns</p>
</div>



### Analysis


```python
def protocol3_analysis(data, column):
    print(f"MANOVA analysis for {column}")
    print(
        MANOVA.from_formula(
            f"C(Target) ~ {column}",
            data=data[data["Target"].isin(["siLuc", "siPTENP1", "siPTEN/PTENP1"])],
        ).mv_test()
    )
    formula = f"{column} ~ C(Target)"
    lm = ols(formula, data[data["Target"].isin(["siLuc", "siPTEN"])]).fit()
    print(f"ANOVA analysis for {column} with targets siLuc and siPTEN")
    print(lm.summary())
    print(anova_lm(lm))
    formula = f"{column} ~ C(Target)"
    lm = ols(formula, data[data["Target"].isin(["siLuc", "siPTENP1"])]).fit()
    print(f"ANOVA analysis for {column} with targets siLuc and siPTENP1")
    print(lm.summary())
    print(anova_lm(lm))
    formula = f"{column} ~ C(Target)"
    lm = ols(formula, data[data["Target"].isin(["siLuc", "siPTEN/PTENP1"])]).fit()
    print(f"ANOVA analysis for {column} with targets siLuc and siPTEN/PTENP1")
    print(lm.summary())
    print(anova_lm(lm))
```

**Shapiro-Wilk test and Levene test**


```python
columns = ["Cq_36B4", "Cq_Actin", "Cq_PTEN", "Cq_PTENP1"]
data, _ = shapiro_wilk_and_levene(data, columns)
```

    Shapiro-Wilk for Cq_36B4: ShapiroResult(statistic=0.8242849707603455, pvalue=5.169299299723207e-08)
    Shapiro-Wilk for Cq_Actin: ShapiroResult(statistic=0.23744463920593262, pvalue=7.63271397656262e-18)
    Shapiro-Wilk for Cq_PTEN: ShapiroResult(statistic=0.8928728103637695, pvalue=1.115873055823613e-05)
    Shapiro-Wilk for Cq_PTENP1: ShapiroResult(statistic=0.9436253309249878, pvalue=0.002264362992718816)
    Levene: LeveneResult(statistic=3.168455710586697, pvalue=0.04397750506585729)



    
![png](output_28_1.png)
    



    
![png](output_28_2.png)
    



    
![png](output_28_3.png)
    



    
![png](output_28_4.png)
    


**MANOVA and ANOVA**


```python
for column in columns:
    protocol3_analysis(data, column+ "_standard")
```

    MANOVA analysis for Cq_36B4_standard
                                     Multivariate linear model
    ============================================================================================
                                                                                                
    --------------------------------------------------------------------------------------------
           Intercept                Value          Num DF  Den DF         F Value         Pr > F
    --------------------------------------------------------------------------------------------
              Wilks' lambda                -0.0000 3.0000 41.0000 -61549194907396792.0000 1.0000
             Pillai's trace                 1.0000 3.0000 41.0000 -61549194907396792.0000 1.0000
     Hotelling-Lawley trace -4503599627370497.0000 3.0000 41.0000 -61549194907396792.0000 1.0000
        Roy's greatest root -4503599627370497.0000 3.0000 41.0000 -61549194907396792.0000 1.0000
    --------------------------------------------------------------------------------------------
                                                                                                
    --------------------------------------------------------------------------------------------------
                Cq_36B4_standard          Value        Num DF        Den DF       F Value       Pr > F
    --------------------------------------------------------------------------------------------------
                      Wilks' lambda       0.6466       2.0000       42.0000       11.4751       0.0001
                     Pillai's trace       0.3591       2.0000       42.0000       11.7655       0.0001
             Hotelling-Lawley trace       0.5376       2.0000       42.0000       11.2890       0.0001
                Roy's greatest root       0.5205       2.0000       42.0000       10.9314       0.0002
    ============================================================================================
    
    ANOVA analysis for Cq_36B4_standard with targets siLuc and siPTEN
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_36B4_standard   R-squared:                       0.253
    Model:                            OLS   Adj. R-squared:                  0.226
    Method:                 Least Squares   F-statistic:                     9.482
    Date:                Mon, 08 May 2023   Prob (F-statistic):            0.00461
    Time:                        22:45:27   Log-Likelihood:                -28.128
    No. Observations:                  30   AIC:                             60.26
    Df Residuals:                      28   BIC:                             63.06
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =======================================================================================
                              coef    std err          t      P>|t|      [0.025      0.975]
    ---------------------------------------------------------------------------------------
    Intercept              -0.5345      0.165     -3.236      0.003      -0.873      -0.196
    C(Target)[T.siPTEN]     0.7192      0.234      3.079      0.005       0.241       1.198
    ==============================================================================
    Omnibus:                        2.223   Durbin-Watson:                   0.836
    Prob(Omnibus):                  0.329   Jarque-Bera (JB):                1.894
    Skew:                           0.594   Prob(JB):                        0.388
    Kurtosis:                       2.679   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   3.879418  3.879418  9.481896  0.004613
    Residual   28.0  11.455906  0.409139       NaN       NaN
    ANOVA analysis for Cq_36B4_standard with targets siLuc and siPTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_36B4_standard   R-squared:                       0.427
    Model:                            OLS   Adj. R-squared:                  0.406
    Method:                 Least Squares   F-statistic:                     20.82
    Date:                Mon, 08 May 2023   Prob (F-statistic):           9.14e-05
    Time:                        22:45:27   Log-Likelihood:                -39.837
    No. Observations:                  30   AIC:                             83.67
    Df Residuals:                      28   BIC:                             86.48
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =========================================================================================
                                coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------------
    Intercept                -0.5345      0.244     -2.190      0.037      -1.034      -0.035
    C(Target)[T.siPTENP1]     1.5747      0.345      4.563      0.000       0.868       2.282
    ==============================================================================
    Omnibus:                        1.723   Durbin-Watson:                   0.701
    Prob(Omnibus):                  0.422   Jarque-Bera (JB):                1.057
    Skew:                           0.025   Prob(JB):                        0.589
    Kurtosis:                       2.082   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq    mean_sq          F    PR(>F)
    C(Target)   1.0  18.598148  18.598148  20.824802  0.000091
    Residual   28.0  25.006151   0.893077        NaN       NaN
    ANOVA analysis for Cq_36B4_standard with targets siLuc and siPTEN/PTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_36B4_standard   R-squared:                       0.101
    Model:                            OLS   Adj. R-squared:                  0.069
    Method:                 Least Squares   F-statistic:                     3.146
    Date:                Mon, 08 May 2023   Prob (F-statistic):             0.0870
    Time:                        22:45:27   Log-Likelihood:                -32.621
    No. Observations:                  30   AIC:                             69.24
    Df Residuals:                      28   BIC:                             72.04
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================================
                                     coef    std err          t      P>|t|      [0.025      0.975]
    ----------------------------------------------------------------------------------------------
    Intercept                     -0.5345      0.192     -2.786      0.009      -0.927      -0.142
    C(Target)[T.siPTEN/PTENP1]     0.4812      0.271      1.774      0.087      -0.075       1.037
    ==============================================================================
    Omnibus:                       14.583   Durbin-Watson:                   0.618
    Prob(Omnibus):                  0.001   Jarque-Bera (JB):               14.800
    Skew:                           1.585   Prob(JB):                     0.000611
    Kurtosis:                       4.336   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   1.736401  1.736401  3.145556  0.087012
    Residual   28.0  15.456484  0.552017       NaN       NaN
    MANOVA analysis for Cq_Actin_standard
                                    Multivariate linear model
    ==========================================================================================
                                                                                              
    ------------------------------------------------------------------------------------------
           Intercept                Value         Num DF  Den DF        F Value         Pr > F
    ------------------------------------------------------------------------------------------
              Wilks' lambda                0.0000 3.0000 41.0000 15387298726849182.0000 0.0000
             Pillai's trace                1.0000 3.0000 41.0000 15387298726849180.0000 0.0000
     Hotelling-Lawley trace 1125899906842623.0000 3.0000 41.0000 15387298726849180.0000 0.0000
        Roy's greatest root 1125899906842623.0000 3.0000 41.0000 15387298726849180.0000 0.0000
    ------------------------------------------------------------------------------------------
                                                                                              
    ------------------------------------------------------------------------------------------------
             Cq_Actin_standard          Value        Num DF        Den DF       F Value       Pr > F
    ------------------------------------------------------------------------------------------------
                    Wilks' lambda       0.9851       3.0000       41.0000        0.2073       0.8908
                   Pillai's trace       0.0149       3.0000       41.0000        0.2073       0.8908
           Hotelling-Lawley trace       0.0152       3.0000       41.0000        0.2073       0.8908
              Roy's greatest root       0.0152       3.0000       41.0000        0.2073       0.8908
    ==========================================================================================
    
    ANOVA analysis for Cq_Actin_standard with targets siLuc and siPTEN
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:      Cq_Actin_standard   R-squared:                       0.018
    Model:                            OLS   Adj. R-squared:                 -0.017
    Method:                 Least Squares   F-statistic:                    0.5043
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.484
    Time:                        22:45:27   Log-Likelihood:                -55.623
    No. Observations:                  30   AIC:                             115.2
    Df Residuals:                      28   BIC:                             118.0
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =======================================================================================
                              coef    std err          t      P>|t|      [0.025      0.975]
    ---------------------------------------------------------------------------------------
    Intercept               0.2908      0.413      0.704      0.487      -0.555       1.137
    C(Target)[T.siPTEN]    -0.4147      0.584     -0.710      0.484      -1.611       0.782
    ==============================================================================
    Omnibus:                       68.237   Durbin-Watson:                   2.119
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):              754.498
    Skew:                           4.826   Prob(JB):                    1.45e-164
    Kurtosis:                      25.593   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   1.290079  1.290079  0.504271  0.483502
    Residual   28.0  71.632618  2.558308       NaN       NaN
    ANOVA analysis for Cq_Actin_standard with targets siLuc and siPTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:      Cq_Actin_standard   R-squared:                       0.006
    Model:                            OLS   Adj. R-squared:                 -0.030
    Method:                 Least Squares   F-statistic:                    0.1615
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.691
    Time:                        22:45:27   Log-Likelihood:                -55.669
    No. Observations:                  30   AIC:                             115.3
    Df Residuals:                      28   BIC:                             118.1
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =========================================================================================
                                coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------------
    Intercept                 0.2908      0.414      0.703      0.488      -0.556       1.138
    C(Target)[T.siPTENP1]    -0.2351      0.585     -0.402      0.691      -1.433       0.963
    ==============================================================================
    Omnibus:                       67.988   Durbin-Watson:                   2.116
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):              744.688
    Skew:                           4.804   Prob(JB):                    1.96e-162
    Kurtosis:                      25.437   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   0.414379  0.414379  0.161481  0.690847
    Residual   28.0  71.851104  2.566111       NaN       NaN
    ANOVA analysis for Cq_Actin_standard with targets siLuc and siPTEN/PTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:      Cq_Actin_standard   R-squared:                       0.015
    Model:                            OLS   Adj. R-squared:                 -0.020
    Method:                 Least Squares   F-statistic:                    0.4199
    Date:                Mon, 08 May 2023   Prob (F-statistic):              0.522
    Time:                        22:45:27   Log-Likelihood:                -55.634
    No. Observations:                  30   AIC:                             115.3
    Df Residuals:                      28   BIC:                             118.1
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================================
                                     coef    std err          t      P>|t|      [0.025      0.975]
    ----------------------------------------------------------------------------------------------
    Intercept                      0.2908      0.413      0.704      0.487      -0.555       1.137
    C(Target)[T.siPTEN/PTENP1]    -0.3786      0.584     -0.648      0.522      -1.575       0.818
    ==============================================================================
    Omnibus:                       68.184   Durbin-Watson:                   2.175
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):              752.323
    Skew:                           4.822   Prob(JB):                    4.32e-164
    Kurtosis:                      25.558   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   1.075030  1.075030  0.419926  0.522253
    Residual   28.0  71.681221  2.560044       NaN       NaN
    MANOVA analysis for Cq_PTEN_standard
                                    Multivariate linear model
    ==========================================================================================
                                                                                              
    ------------------------------------------------------------------------------------------
           Intercept                Value         Num DF  Den DF        F Value         Pr > F
    ------------------------------------------------------------------------------------------
              Wilks' lambda                0.0000 3.0000 41.0000 61549194907396768.0000 0.0000
             Pillai's trace                1.0000 3.0000 41.0000 61549194907396760.0000 0.0000
     Hotelling-Lawley trace 4503599627370495.0000 3.0000 41.0000 61549194907396760.0000 0.0000
        Roy's greatest root 4503599627370495.0000 3.0000 41.0000 61549194907396760.0000 0.0000
    ------------------------------------------------------------------------------------------
                                                                                              
    ------------------------------------------------------------------------------------------------
              Cq_PTEN_standard          Value        Num DF        Den DF       F Value       Pr > F
    ------------------------------------------------------------------------------------------------
                    Wilks' lambda       0.3043       2.0000       42.0000       48.0104       0.0000
                   Pillai's trace       0.6957       2.0000       42.0000       48.0104       0.0000
           Hotelling-Lawley trace       2.2862       2.0000       42.0000       48.0104       0.0000
              Roy's greatest root       2.2862       2.0000       42.0000       48.0104       0.0000
    ==========================================================================================
    
    ANOVA analysis for Cq_PTEN_standard with targets siLuc and siPTEN
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_PTEN_standard   R-squared:                       0.898
    Model:                            OLS   Adj. R-squared:                  0.895
    Method:                 Least Squares   F-statistic:                     247.4
    Date:                Mon, 08 May 2023   Prob (F-statistic):           1.99e-15
    Time:                        22:45:27   Log-Likelihood:                -8.7344
    No. Observations:                  30   AIC:                             21.47
    Df Residuals:                      28   BIC:                             24.27
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =======================================================================================
                              coef    std err          t      P>|t|      [0.025      0.975]
    ---------------------------------------------------------------------------------------
    Intercept              -0.9614      0.087    -11.111      0.000      -1.139      -0.784
    C(Target)[T.siPTEN]     1.9245      0.122     15.728      0.000       1.674       2.175
    ==============================================================================
    Omnibus:                        1.342   Durbin-Watson:                   0.461
    Prob(Omnibus):                  0.511   Jarque-Bera (JB):                1.142
    Skew:                           0.289   Prob(JB):                        0.565
    Kurtosis:                       2.238   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq    mean_sq           F        PR(>F)
    C(Target)   1.0  27.777737  27.777737  247.355006  1.985439e-15
    Residual   28.0   3.144374   0.112299         NaN           NaN
    ANOVA analysis for Cq_PTEN_standard with targets siLuc and siPTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_PTEN_standard   R-squared:                       0.449
    Model:                            OLS   Adj. R-squared:                  0.429
    Method:                 Least Squares   F-statistic:                     22.80
    Date:                Mon, 08 May 2023   Prob (F-statistic):           5.14e-05
    Time:                        22:45:27   Log-Likelihood:                -24.564
    No. Observations:                  30   AIC:                             53.13
    Df Residuals:                      28   BIC:                             55.93
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =========================================================================================
                                coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------------
    Intercept                -0.9614      0.147     -6.555      0.000      -1.262      -0.661
    C(Target)[T.siPTENP1]     0.9902      0.207      4.774      0.000       0.565       1.415
    ==============================================================================
    Omnibus:                        1.016   Durbin-Watson:                   0.463
    Prob(Omnibus):                  0.602   Jarque-Bera (JB):                0.876
    Skew:                           0.156   Prob(JB):                        0.645
    Kurtosis:                       2.223   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df    sum_sq   mean_sq          F    PR(>F)
    C(Target)   1.0  7.354024  7.354024  22.795216  0.000051
    Residual   28.0  9.033153  0.322613        NaN       NaN
    ANOVA analysis for Cq_PTEN_standard with targets siLuc and siPTEN/PTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:       Cq_PTEN_standard   R-squared:                       0.869
    Model:                            OLS   Adj. R-squared:                  0.864
    Method:                 Least Squares   F-statistic:                     184.9
    Date:                Mon, 08 May 2023   Prob (F-statistic):           7.37e-14
    Time:                        22:45:27   Log-Likelihood:                -13.789
    No. Observations:                  30   AIC:                             31.58
    Df Residuals:                      28   BIC:                             34.38
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================================
                                     coef    std err          t      P>|t|      [0.025      0.975]
    ----------------------------------------------------------------------------------------------
    Intercept                     -0.9614      0.102     -9.388      0.000      -1.171      -0.752
    C(Target)[T.siPTEN/PTENP1]     1.9695      0.145     13.600      0.000       1.673       2.266
    ==============================================================================
    Omnibus:                        2.209   Durbin-Watson:                   0.378
    Prob(Omnibus):                  0.331   Jarque-Bera (JB):                1.501
    Skew:                           0.548   Prob(JB):                        0.472
    Kurtosis:                       3.024   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq    mean_sq           F        PR(>F)
    C(Target)   1.0  29.091484  29.091484  184.949444  7.366661e-14
    Residual   28.0   4.404239   0.157294         NaN           NaN
    MANOVA analysis for Cq_PTENP1_standard
                                    Multivariate linear model
    =========================================================================================
                                                                                             
    -----------------------------------------------------------------------------------------
           Intercept               Value         Num DF  Den DF        F Value         Pr > F
    -----------------------------------------------------------------------------------------
              Wilks' lambda               0.0000 3.0000 41.0000 12309838981479344.0000 0.0000
             Pillai's trace               1.0000 3.0000 41.0000 12309838981479340.0000 0.0000
     Hotelling-Lawley trace 900719925474098.2500 3.0000 41.0000 12309838981479342.0000 0.0000
        Roy's greatest root 900719925474098.2500 3.0000 41.0000 12309838981479342.0000 0.0000
    -----------------------------------------------------------------------------------------
                                                                                             
    ----------------------------------------------------------------------------------------------
               Cq_PTENP1_standard        Value       Num DF       Den DF      F Value       Pr > F
    ----------------------------------------------------------------------------------------------
                      Wilks' lambda      0.1707      2.0000      42.0000      102.0428      0.0000
                     Pillai's trace      0.8431      2.0000      42.0000      112.8446      0.0000
             Hotelling-Lawley trace      4.7785      2.0000      42.0000      100.3480      0.0000
                Roy's greatest root      4.7615      2.0000      42.0000       99.9921      0.0000
    =========================================================================================
    
    ANOVA analysis for Cq_PTENP1_standard with targets siLuc and siPTEN
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:     Cq_PTENP1_standard   R-squared:                       0.265
    Model:                            OLS   Adj. R-squared:                  0.238
    Method:                 Least Squares   F-statistic:                     10.08
    Date:                Mon, 08 May 2023   Prob (F-statistic):            0.00363
    Time:                        22:45:27   Log-Likelihood:                -27.215
    No. Observations:                  30   AIC:                             58.43
    Df Residuals:                      28   BIC:                             61.23
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =======================================================================================
                              coef    std err          t      P>|t|      [0.025      0.975]
    ---------------------------------------------------------------------------------------
    Intercept              -0.9902      0.160     -6.181      0.000      -1.318      -0.662
    C(Target)[T.siPTEN]     0.7192      0.227      3.175      0.004       0.255       1.183
    ==============================================================================
    Omnibus:                        0.956   Durbin-Watson:                   0.383
    Prob(Omnibus):                  0.620   Jarque-Bera (JB):                0.932
    Skew:                           0.261   Prob(JB):                        0.628
    Kurtosis:                       2.312   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq   mean_sq         F    PR(>F)
    C(Target)   1.0   3.879775  3.879775  10.07761  0.003632
    Residual   28.0  10.779708  0.384990       NaN       NaN
    ANOVA analysis for Cq_PTENP1_standard with targets siLuc and siPTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:     Cq_PTENP1_standard   R-squared:                       0.898
    Model:                            OLS   Adj. R-squared:                  0.894
    Method:                 Least Squares   F-statistic:                     246.5
    Date:                Mon, 08 May 2023   Prob (F-statistic):           2.08e-15
    Time:                        22:45:27   Log-Likelihood:                -15.150
    No. Observations:                  30   AIC:                             34.30
    Df Residuals:                      28   BIC:                             37.10
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    =========================================================================================
                                coef    std err          t      P>|t|      [0.025      0.975]
    -----------------------------------------------------------------------------------------
    Intercept                -0.9902      0.107     -9.241      0.000      -1.210      -0.771
    C(Target)[T.siPTENP1]     2.3790      0.152     15.699      0.000       2.069       2.689
    ==============================================================================
    Omnibus:                        4.850   Durbin-Watson:                   0.863
    Prob(Omnibus):                  0.088   Jarque-Bera (JB):                1.992
    Skew:                           0.265   Prob(JB):                        0.369
    Kurtosis:                       1.854   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq    mean_sq           F        PR(>F)
    C(Target)   1.0  42.447951  42.447951  246.452913  2.079138e-15
    Residual   28.0   4.822595   0.172236         NaN           NaN
    ANOVA analysis for Cq_PTENP1_standard with targets siLuc and siPTEN/PTENP1
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:     Cq_PTENP1_standard   R-squared:                       0.714
    Model:                            OLS   Adj. R-squared:                  0.703
    Method:                 Least Squares   F-statistic:                     69.76
    Date:                Mon, 08 May 2023   Prob (F-statistic):           4.36e-09
    Time:                        22:45:27   Log-Likelihood:                -20.942
    No. Observations:                  30   AIC:                             45.88
    Df Residuals:                      28   BIC:                             48.69
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================================
                                     coef    std err          t      P>|t|      [0.025      0.975]
    ----------------------------------------------------------------------------------------------
    Intercept                     -0.9902      0.130     -7.618      0.000      -1.256      -0.724
    C(Target)[T.siPTEN/PTENP1]     1.5353      0.184      8.352      0.000       1.159       1.912
    ==============================================================================
    Omnibus:                        1.357   Durbin-Watson:                   0.938
    Prob(Omnibus):                  0.507   Jarque-Bera (JB):                1.037
    Skew:                          -0.191   Prob(JB):                        0.595
    Kurtosis:                       2.173   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
                 df     sum_sq    mean_sq          F        PR(>F)
    C(Target)   1.0  17.678515  17.678515  69.763548  4.363686e-09
    Residual   28.0   7.095374   0.253406        NaN           NaN


## Protocol 4

Confirmatory analysis plan <br />
This replication attempt will perform the following statistical analysis listed below.<br />
■Statistical Analysis:<br />
○Note: at the time of analysis, we will perform the Shapiro–Wilk test and generate a quantile–quantile plot to assess the normality of the data. We will also perform Levene’s test to assess homoscedasticity. If the data appear skewed we will perform the appropriate transformation inorder to proceed with the proposed statistical analysis. If this is not possible we will perform the equivalent non-parametric test.<br />


### [Import data](https://osf.io/95cmp)


```python
data = pd.read_csv("data/Study_1_Protocol_4_Data.csv")
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Repeat</th>
      <th>Unnamed: 1</th>
      <th>Hsp90.raw</th>
      <th>Hsp90.background</th>
      <th>hsp90.corrected</th>
      <th>Pten.norm.Hsp90</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Untransfected</td>
      <td>115</td>
      <td>37</td>
      <td>78</td>
      <td>0.820513</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>SiLUC</td>
      <td>124</td>
      <td>30</td>
      <td>94</td>
      <td>0.691489</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>Pten</td>
      <td>107</td>
      <td>32</td>
      <td>75</td>
      <td>0.560000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>Ptenp1</td>
      <td>146</td>
      <td>26</td>
      <td>120</td>
      <td>0.458333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>Pten/ptenp1</td>
      <td>101</td>
      <td>24</td>
      <td>77</td>
      <td>0.116883</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2</td>
      <td>Untransfected</td>
      <td>178</td>
      <td>84</td>
      <td>94</td>
      <td>0.297872</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>SiLUC</td>
      <td>181</td>
      <td>82</td>
      <td>99</td>
      <td>0.272727</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2</td>
      <td>Pten</td>
      <td>174</td>
      <td>82</td>
      <td>92</td>
      <td>0.076087</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2</td>
      <td>Ptenp1</td>
      <td>178</td>
      <td>82</td>
      <td>96</td>
      <td>0.166667</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2</td>
      <td>Pten/ptenp1</td>
      <td>187</td>
      <td>86</td>
      <td>101</td>
      <td>0.059406</td>
    </tr>
    <tr>
      <th>10</th>
      <td>3</td>
      <td>Untransfected</td>
      <td>98</td>
      <td>20</td>
      <td>78</td>
      <td>0.179000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>3</td>
      <td>SiLUC</td>
      <td>138</td>
      <td>28</td>
      <td>110</td>
      <td>0.281000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>3</td>
      <td>Pten</td>
      <td>123</td>
      <td>28</td>
      <td>95</td>
      <td>0.084000</td>
    </tr>
    <tr>
      <th>13</th>
      <td>3</td>
      <td>Ptenp1</td>
      <td>138</td>
      <td>37</td>
      <td>101</td>
      <td>0.178000</td>
    </tr>
    <tr>
      <th>14</th>
      <td>3</td>
      <td>Pten/ptenp1</td>
      <td>143</td>
      <td>31</td>
      <td>112</td>
      <td>0.035000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>4</td>
      <td>Untransfected</td>
      <td>155</td>
      <td>76</td>
      <td>79</td>
      <td>0.582278</td>
    </tr>
    <tr>
      <th>16</th>
      <td>4</td>
      <td>SiLUC</td>
      <td>110</td>
      <td>36</td>
      <td>74</td>
      <td>0.527027</td>
    </tr>
    <tr>
      <th>17</th>
      <td>4</td>
      <td>Pten</td>
      <td>108</td>
      <td>32</td>
      <td>76</td>
      <td>0.131579</td>
    </tr>
    <tr>
      <th>18</th>
      <td>4</td>
      <td>Ptenp1</td>
      <td>99</td>
      <td>33</td>
      <td>66</td>
      <td>0.303030</td>
    </tr>
    <tr>
      <th>19</th>
      <td>4</td>
      <td>Pten/ptenp1</td>
      <td>115</td>
      <td>26</td>
      <td>89</td>
      <td>0.134831</td>
    </tr>
    <tr>
      <th>20</th>
      <td>5</td>
      <td>Untransfected</td>
      <td>161</td>
      <td>32</td>
      <td>129</td>
      <td>0.403000</td>
    </tr>
    <tr>
      <th>21</th>
      <td>5</td>
      <td>SiLUC</td>
      <td>130</td>
      <td>20</td>
      <td>110</td>
      <td>0.281000</td>
    </tr>
    <tr>
      <th>22</th>
      <td>5</td>
      <td>Pten</td>
      <td>125</td>
      <td>18</td>
      <td>107</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>23</th>
      <td>5</td>
      <td>Ptenp1</td>
      <td>123</td>
      <td>18</td>
      <td>105</td>
      <td>0.219000</td>
    </tr>
    <tr>
      <th>24</th>
      <td>5</td>
      <td>Pten/ptenp1</td>
      <td>133</td>
      <td>21</td>
      <td>112</td>
      <td>0.008900</td>
    </tr>
  </tbody>
</table>
</div>



**Shapiro-Wilk test and Levene test**


```python
data, _ = shapiro_wilk_and_levene(
    data, [" Hsp90.raw", "Hsp90.background", "hsp90.corrected", "Pten.norm.Hsp90"]
)
```

    Shapiro-Wilk for  Hsp90.raw: ShapiroResult(statistic=0.9261247515678406, pvalue=0.07075543701648712)
    Shapiro-Wilk for Hsp90.background: ShapiroResult(statistic=0.7422038316726685, pvalue=2.8479855245677754e-05)
    Shapiro-Wilk for hsp90.corrected: ShapiroResult(statistic=0.9641509652137756, pvalue=0.5031609535217285)
    Shapiro-Wilk for Pten.norm.Hsp90: ShapiroResult(statistic=0.9163461923599243, pvalue=0.04232637584209442)
    Levene: LeveneResult(statistic=2.253989855251763, pvalue=0.11233819633272497)



    
![png](output_36_1.png)
    



    
![png](output_36_2.png)
    



    
![png](output_36_3.png)
    



    
![png](output_36_4.png)
    


○Two-way ANOVA of normalized PTEN levels in siLuc, siPTEN, siPTENP1, or siPTEN/PTENP1 siRNA transfected cells with the following planned comparisons using the Bonferroni correction:<br />
1. siLuc compared to siPTEN.<br />
2. siLuc compared to siPTENP1.<br />
3. siLuc compared to siPTEN/PTENP1.<br />
4. siPTEN/PTENP1 compared to siPTEN.<br />
5. siPTEN/PTENP1 compared to siPTENP1.<br />

## Protocol 5
Confirmatory analysis plan<br />
This replication attempt will perform the following statistical analysis listed below.<br />
■Statistical Analysis:<br />
○Note: at the time of analysis, we will perform the Shapiro–Wilk test and generate a quantile–quantileplot to assess the normality of the data. We will also perform Levene’s test to assess homoscedasticity.If the data appear skewed we will perform the appropriate transformation in order to proceed with theproposed statistical analysis. If this is not possible we will perform the equivalent non-parametric test. <br />
○Unpaired two-tailedt-test ofPTENP1mRNA levels of pCMV transfected cells compared topCMV/PTEN3′UTR transfected cells.

## Protocol 6
Confirmatory analysis plan<br />
This replication attempt will perform the following statistical analysis listed below.<br />
■Statistical Analysis:<br />
○Note: at the time of analysis, we will perform the Shapiro–Wilk test and generate a quantile–quantile plot to assess the normality of the data. We will also perform Levene’s test to assesshomoscedasticity. If the data appear skewed we will perform the appropriate transformation inorder to proceed with the proposed statistical analysis. If this is not possible we will perform theequivalent non-parametric test.<br />
○Unpaired two-tailed t-test of Day 5 absorbance of pCMV transfected cells compared to pCMV/PTEN3′UTR transfected cells

### Environment


```python
with open("../environment.yml", "r") as f:
    content = f.read()
print(content)
```

    name: reproducibility_hackathon
    channels:
      - conda-forge
      - defaults
    dependencies:
      - _libgcc_mutex=0.1=conda_forge
      - _openmp_mutex=4.5=2_gnu
      - bzip2=1.0.8=h7f98852_4
      - ca-certificates=2022.12.7=ha878542_0
      - ld_impl_linux-64=2.40=h41732ed_0
      - libexpat=2.5.0=hcb278e6_1
      - libffi=3.4.2=h7f98852_5
      - libgcc-ng=12.2.0=h65d4601_19
      - libgomp=12.2.0=h65d4601_19
      - libnsl=2.0.0=h7f98852_0
      - libsqlite=3.40.0=h753d276_1
      - libuuid=2.38.1=h0b41bf4_0
      - libzlib=1.2.13=h166bdaf_4
      - ncurses=6.3=h27087fc_1
      - openssl=3.1.0=hd590300_3
      - pip=23.1.2=pyhd8ed1ab_0
      - python=3.11.3=h2755cc3_0_cpython
      - readline=8.2=h8228510_1
      - setuptools=67.7.2=pyhd8ed1ab_0
      - tk=8.6.12=h27826a3_0
      - wheel=0.40.0=pyhd8ed1ab_0
      - xz=5.2.6=h166bdaf_0
      - pip:
          - anyio==3.6.2
          - argon2-cffi==21.3.0
          - argon2-cffi-bindings==21.2.0
          - arrow==1.2.3
          - asttokens==2.2.1
          - attrs==23.1.0
          - backcall==0.2.0
          - beautifulsoup4==4.12.2
          - bleach==6.0.0
          - cffi==1.15.1
          - comm==0.1.3
          - contourpy==1.0.7
          - cycler==0.11.0
          - debugpy==1.6.7
          - decorator==5.1.1
          - defusedxml==0.7.1
          - executing==1.2.0
          - fastjsonschema==2.16.3
          - fonttools==4.39.3
          - fqdn==1.5.1
          - idna==3.4
          - ipykernel==6.22.0
          - ipython==8.13.2
          - ipython-genutils==0.2.0
          - ipywidgets==8.0.6
          - isoduration==20.11.0
          - jedi==0.18.2
          - jinja2==3.1.2
          - jsonpointer==2.3
          - jsonschema==4.17.3
          - jupyter==1.0.0
          - jupyter-client==8.2.0
          - jupyter-console==6.6.3
          - jupyter-core==5.3.0
          - jupyter-events==0.6.3
          - jupyter-server==2.5.0
          - jupyter-server-terminals==0.4.4
          - jupyterlab-pygments==0.2.2
          - jupyterlab-widgets==3.0.7
          - kiwisolver==1.4.4
          - markupsafe==2.1.2
          - matplotlib==3.7.1
          - matplotlib-inline==0.1.6
          - mistune==2.0.5
          - nbclassic==1.0.0
          - nbclient==0.7.4
          - nbconvert==7.3.1
          - nbformat==5.8.0
          - nest-asyncio==1.5.6
          - notebook==6.5.4
          - notebook-shim==0.2.3
          - numpy==1.24.3
          - packaging==23.1
          - pandas==2.0.1
          - pandocfilters==1.5.0
          - parso==0.8.3
          - patsy==0.5.3
          - pexpect==4.8.0
          - pickleshare==0.7.5
          - pillow==9.5.0
          - platformdirs==3.5.0
          - prometheus-client==0.16.0
          - prompt-toolkit==3.0.38
          - psutil==5.9.5
          - ptyprocess==0.7.0
          - pure-eval==0.2.2
          - pycparser==2.21
          - pygments==2.15.1
          - pyparsing==3.0.9
          - pyrsistent==0.19.3
          - python-dateutil==2.8.2
          - python-json-logger==2.0.7
          - pytz==2023.3
          - pyyaml==6.0
          - pyzmq==25.0.2
          - qtconsole==5.4.2
          - qtpy==2.3.1
          - rfc3339-validator==0.1.4
          - rfc3986-validator==0.1.1
          - scipy==1.10.1
          - send2trash==1.8.2
          - six==1.16.0
          - sniffio==1.3.0
          - soupsieve==2.4.1
          - stack-data==0.6.2
          - statsmodels==0.13.5
          - terminado==0.17.1
          - tinycss2==1.2.1
          - tornado==6.3.1
          - traitlets==5.9.0
          - tzdata==2023.3
          - uri-template==1.2.0
          - wcwidth==0.2.6
          - webcolors==1.13
          - webencodings==0.5.1
          - websocket-client==1.5.1
          - widgetsnbextension==4.0.7
    prefix: /home/jannik-gut/miniconda3/envs/reproducibility_hackathon
    

